<template>
  <div class="p-6 max-w-xl mx-auto">
    <h1>Short Link Service</h1>
    <p>POST <code>/v1/links</code> with JSON <code>{"url": "https://example.com"}</code> to create a short link.</p>
  </div>
</template>
